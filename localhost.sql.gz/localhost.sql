-- Adminer 4.8.1 MySQL 5.7.21-20-beget-5.7.21-20-1-log dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `tasks`;
CREATE TABLE `tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `state` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;

INSERT INTO `tasks` (`id`, `user`, `email`, `description`, `state`) VALUES
(5,	'Tester1',	'tester@mail.com',	'Потестить форму 1.',	0),
(6,	'Tester2',	'tester@mail.com',	'Потестить форму 2.',	0),
(7,	'Tester1',	'tester@mail.com',	'Потестить форму 3.',	1),
(8,	'Tester3',	'tester@mail.com',	'Потестить форму 4.',	0),
(9,	'Tester2',	'tester@mail.com',	'Потестить форму 5.',	0),
(10,	'Tester1',	'tester@mail.com',	'Потестить форму 6.',	0),
(11,	'Tester2',	'tester@mail.com',	'Потестить форму 7.',	0),
(12,	'Tester1',	'tester@mail.com',	'Потестить форму 8.',	1),
(13,	'Tester3',	'tester@mail.com',	'Потестить форму 9.',	0),
(14,	'Tester2',	'tester@mail.com',	'Потестить форму 10.',	1),
(17,	'qwerty',	'qwerty@mail.com',	'qwerty qwerty',	0),
(18,	'asd',	'asd@asd.ru',	'`test\r\n&quot;&gt;&lt;h1&gt;test&lt;/h1&gt;\r\n&#039;+alert(1)+&#039;\r\n&quot;onmouserover=&quot;alert(1)\r\nhttp://&quot;onmouseover=&quot;alert(1)\r\n&lt;script&gt;alert(&#039;test&#039;);&lt;/script&gt;',	0),
(20,	'zxcv',	'zxcv@zxcv',	'zxcv zxcv',	0),
(26,	'asdqwezxc',	'asd@asd.com',	'ЫЫФЫВОФ',	0),
(27,	'test',	'test@test.com',	'test job 1',	0),
(33,	'test',	'test@test.com',	'test job 2',	0),
(34,	'test',	'test@test.com',	'test job 3',	1),
(35,	'test',	'test@test.com',	'test job 4',	0),
(37,	'tester-xss',	'tester@mail.com',	'`test\r\n\r\n&quot;&gt;&lt;h1&gt;test&lt;/h1&gt;\r\n\r\n&#039;+alert(1)+&#039;\r\n\r\n&quot;onmouserover=&quot;alert(1)\r\n\r\nhttp://&quot;onmouseover=&quot;alert(1)\r\n\r\n&lt;script&gt;alert(&#039;test&#039;);&lt;/script&gt;',	0),
(38,	'test',	'test@test.com',	'test',	0),
(39,	'Pupa',	'pupa@mail.com',	'Получить ЗП в бухгалтерии.',	0),
(40,	'Lupa',	'lupa@mail.com',	'Не перепутать конверты.',	0),
(41,	'Sysadmin',	'sysadmin@mail.com',	'Сделать бэкап.',	0),
(42,	'Developer',	'developer@mail.com',	'Погладить кота.',	1);

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(255) NOT NULL,
  `role` enum('manager','admin') NOT NULL DEFAULT 'manager',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `users` (`id`, `password`, `role`, `active`, `username`) VALUES
(1,	'$2y$10$GzY5t8i0QFm3E.bLFfqtqug/M4v8j7i4uk5XxFgUoPbZn2U9cLZna',	'manager',	1,	'manager'),
(2,	'$2y$10$GzY5t8i0QFm3E.bLFfqtqug/M4v8j7i4uk5XxFgUoPbZn2U9cLZna',	'manager',	0,	'tester');

-- 2023-05-14 20:17:04
